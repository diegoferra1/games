# Clean Games — Offline iPadOS PWA Bundle

Contains **Minesweeper** (`./minesweeper/`) and **Spider Solitaire** (`./spider/`), plus a unified **Clean Games** launcher (`./index.html`), pre-configured with opaque iPad Home Screen icons and full asset-precaching Service Workers so everything runs **100% offline** with **no 7-day sideload expiry**.

## Deploy in 30 Seconds (HTTPS Required by iPadOS Safari)
Pick any free static host and upload this entire `ipad-pwa/` folder:
- **Netlify Drop**: Go to [https://app.netlify.com/drop](https://app.netlify.com/drop) and drag the `ipad-pwa` folder onto the page.
- **Cloudflare Pages**: Create a Direct Upload project and upload the `ipad-pwa` folder.
- **GitHub Pages**: Push the contents of `ipad-pwa` to a repository (or `gh-pages` branch) and enable GitHub Pages.

## Install on Your iPad
1. Open your deployed HTTPS URL in **Safari** on your iPad.
2. Wait 1–2 seconds for the **Offline Ready** badge on the launcher page.
3. Tap **Share** (the square with the upward arrow) → **Add to Home Screen**.

### Optional: Separate Icons for Each Game
- Open **Minesweeper** from the hub (or visit `<your-url>/minesweeper/`), then tap **Share → Add to Home Screen**.
- Open **Spider Solitaire** from the hub (or visit `<your-url>/spider/`), then tap **Share → Add to Home Screen**.

Each game has its own `manifest.webmanifest`, opaque `180×180` `apple-touch-icon.png`, and full offline precache `sw.js`.

## Rebuild Bundle
From the parent folder run:
```powershell
node build-ipad-pwa.mjs
```
