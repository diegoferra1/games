const CACHE_PREFIX = "clean-games-hub";
const CACHE_NAME = "clean-games-hub-6f768d4d18";
const PRECACHE_URLS = [
  "./icons/apple-touch-icon.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./index.html",
  "./manifest.webmanifest",
  "./minesweeper/assets/index-Ta_zByWC.js",
  "./minesweeper/assets/index-psJCcdIi.css",
  "./minesweeper/assets/web-C5me6Aws.js",
  "./minesweeper/assets/web-CjMRb2zb.js",
  "./minesweeper/icons/apple-touch-icon.png",
  "./minesweeper/icons/icon-192.png",
  "./minesweeper/icons/icon-512.png",
  "./minesweeper/icons/icon.svg",
  "./minesweeper/index.html",
  "./minesweeper/manifest.webmanifest",
  "./spider/assets/index-C5h69IXG.js",
  "./spider/assets/index-DzMGBvdO.css",
  "./spider/assets/web-B0oPeHyg.js",
  "./spider/assets/web-DhCvfDu_.js",
  "./spider/icons/apple-touch-icon.png",
  "./spider/icons/icon-192.png",
  "./spider/icons/icon-512.png",
  "./spider/icons/icon.svg",
  "./spider/index.html",
  "./spider/manifest.webmanifest"
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_URLS))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => k.startsWith(CACHE_PREFIX) && k !== CACHE_NAME)
            .map((k) => caches.delete(k))
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    (async () => {
      const cached =
        (await caches.match(req, { ignoreSearch: true })) ||
        (url.pathname.endsWith('/')
          ? await caches.match(new URL('index.html', url).href)
          : null);
      if (cached) {
        return cached;
      }

      try {
        const res = await fetch(req);
        if (res && res.status === 200 && res.type === 'basic') {
          const cache = await caches.open(CACHE_NAME);
          cache.put(req, res.clone());
        }
        return res;
      } catch {
        if (req.mode === 'navigate') {
    const url = new URL(req.url);
    const scopePath = new URL(self.registration.scope).pathname;
    const relPath = url.pathname.startsWith(scopePath)
      ? url.pathname.slice(scopePath.length)
      : url.pathname.replace(/^\/+/, '');
    let fallback = null;
    if (relPath.startsWith('minesweeper')) {
      fallback = (await caches.match('./minesweeper/index.html')) || (await caches.match('./index.html'));
    } else if (relPath.startsWith('spider')) {
      fallback = (await caches.match('./spider/index.html')) || (await caches.match('./index.html'));
    } else {
      fallback = await caches.match('./index.html');
    }
    if (fallback) return fallback;
  }
        return Response.error();
      }
    })()
  );
});
