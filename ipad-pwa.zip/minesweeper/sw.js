const CACHE_PREFIX = "minesweeper-clean";
const CACHE_NAME = "minesweeper-clean-38749fbb96";
const PRECACHE_URLS = [
  "./assets/index-Ta_zByWC.js",
  "./assets/index-psJCcdIi.css",
  "./assets/web-C5me6Aws.js",
  "./assets/web-CjMRb2zb.js",
  "./icons/apple-touch-icon.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon.svg",
  "./index.html",
  "./manifest.webmanifest"
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_URLS))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => k.startsWith(CACHE_PREFIX) && k !== CACHE_NAME)
            .map((k) => caches.delete(k))
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    (async () => {
      const cached =
        (await caches.match(req, { ignoreSearch: true })) ||
        (url.pathname.endsWith('/')
          ? await caches.match(new URL('index.html', url).href)
          : null);
      if (cached) {
        return cached;
      }

      try {
        const res = await fetch(req);
        if (res && res.status === 200 && res.type === 'basic') {
          const cache = await caches.open(CACHE_NAME);
          cache.put(req, res.clone());
        }
        return res;
      } catch {
        if (req.mode === 'navigate') {
    const fallback = await caches.match('./index.html');
    if (fallback) return fallback;
  }
        return Response.error();
      }
    })()
  );
});
